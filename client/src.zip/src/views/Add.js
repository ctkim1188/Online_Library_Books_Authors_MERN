import React from 'react';
import AuthorForm from '../components/AuthorForm';

export default () => {

    return(
        <>
        <h3>Enter a new Author here:</h3>
        <AuthorForm/>
        </>
    )

}